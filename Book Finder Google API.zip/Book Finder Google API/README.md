# book-finder

Web App to find Books info using Google Book API.

### Info

- This is a simple web application to search a book and get its information like author,publish date etc.

### Setup

- Open index.html file in web browser.
